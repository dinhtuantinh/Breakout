# Breakout
To download this project:
   1. Using git
   - Install git: https://git-scm.com/download/win
   - Open cmd and type: " git clone https://github.com/tuananh1810/breakout.git"
   2. Download zip
   - Click on green button "Code"
   - Choose "Download ZIP"

To run this project
   1. Install python: https://www.python.org/downloads/
   - To check python version: type "python --version" in cmd
   2. Install pip
   - Follow the instruction here: https://www.geeksforgeeks.org/how-to-install-pip-on-windows/
   - To check pip version: type "pip --version" in cmd
   3. Install pygame
   - Open cmd and type: "pip install pygame"
   - To check if pygame is working or not: type "python" and "import pygame" in cmd
   4. Type "python Breakout.py" in cmd to run the project
